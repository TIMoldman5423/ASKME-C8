// Fixed catalogue of read-only query shapes. Claude chooses a tool and its arguments; it never writes SQL.
// Every number in an answer must come from one of these results.
const { q } = require('./db');
const FIN = require('./lib-finance');
const BOARD = require('./lib-board');
const MANUALS = require('./lib-manuals');
const r2 = v => (v === null || v === undefined ? null : Math.round(Number(v) * 100) / 100);
const r0 = v => (v === null || v === undefined ? null : Math.round(Number(v)));
const pct = (a, b) => (a != null && b ? Math.round((a / b - 1) * 1000) / 10 : null);

async function latestWeek() { return (await q(`SELECT max(week_ending)::text d FROM weekly_sales`)).rows[0].d; }
async function resolveWeek(w) {
  if (!w || w === 'latest') return latestWeek();
  if (/^-?\d+$/.test(String(w)) && Number(w) <= 0) { // 0 = latest, -1 = week before ...
    const r = await q(`SELECT DISTINCT week_ending::text d FROM weekly_sales ORDER BY d DESC OFFSET $1 LIMIT 1`, [-Number(w)]);
    return r.rows[0]?.d || null;
  }
  return String(w).slice(0, 10);
}

const defs = [
  { name: 'show_on_map', description: 'Put stores on the map window for the user. Call it, with the store_ids you already have from find_store or another lookup, whenever the user asks where a store is, or to show, locate or map one or more stores. After calling it, say in a sentence where the store is, using the address from store_summary when there is one; do not describe the map.',
    input_schema: { type: 'object', properties: { store_ids: { type: 'array', items: { type: 'integer' } } }, required: ['store_ids'] } },
  { name: 'find_store', description: 'Find stores by a spoken or typed name (e.g. "Hawthorn", "Toowoomba noodle box"). Returns candidate stores with ids. Always call this first when the user names a store and no store_id is given. If several brands match, ask the user which one.',
    input_schema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] } },
  { name: 'store_summary', description: 'Profile of one store (brand, state, address, trading company, BDM, opening date and how reliable it is) plus latest-week sales, orders, average transaction value (ATV when available), change vs previous week, 4-week average, 13-week average, and rank within its brand for the latest week.',
    input_schema: { type: 'object', properties: { store_id: { type: 'integer' } }, required: ['store_id'] } },
  { name: 'stores_by_opening', description: 'List active stores by opening date: those opened at least N years ago (min_years) and/or no more than N years ago (max_years), optionally for one brand and/or state, oldest first. Each store shows its opening date, where the date came from and how reliable it is. Reliability matters: "high" is an actual trading/opening date; "medium" is the Franchise Master opening date; "low" means only the franchise agreement start date is held (a proxy, the store probably opened later). Always tell the user how many dates are low reliability and say so when giving them. Use this for questions like "which Noodle Box stores opened more than five years ago".',
    input_schema: { type: 'object', properties: { brand: { type: 'string' }, state: { type: 'string' }, min_years: { type: 'number' }, max_years: { type: 'number' }, limit: { type: 'integer' }, offset: { type: 'integer' } } } },
  { name: 'rank_stores_growth', description: 'Rank stores by like-for-like year-on-year sales growth over the last N weeks (default 13), optionally for one brand and/or state. For each store it compares its sales in those weeks with the SAME weeks a year earlier (364 days), counting only weeks where the store traded in both. Stores under a year old (not enough matching prior-year weeks) are excluded and counted in excluded_new_or_short_history. order = "top" (best growth, default) or "bottom". limit up to 100, offset pages. Use this for questions like best / worst stores by growth, year on year, LFL by store. Say the period covered and how many stores were excluded. Results marked caution opened close to the prior-year weeks (ramp-up), so say their growth is flattered and consider reading them separately.',
    input_schema: { type: 'object', properties: { weeks: { type: 'integer', description: 'window length in weeks ending at the latest week, default 13, max 52' }, brand: { type: 'string' }, state: { type: 'string' }, order: { type: 'string', enum: ['top', 'bottom'] }, limit: { type: 'integer' }, offset: { type: 'integer' } } } },
  { name: 'weekly_trend', description: 'Company-wide (or one brand / state) sales for EACH week over the last N weeks (default 52), with the number of stores trading, and LIKE-FOR-LIKE (LFL): for each week, the sales of stores that traded in both that week and the same week a year earlier, compared with those same stores a year earlier, giving LFL growth %. LFL needs a year of history; weeks without a year-earlier comparison show lfl null, and the result says how many weeks of history are held. When the weekly like-for-like % from Power BI has been loaded (Admin upload), that is used and quoted as the Power BI figure. A bar chart of the result is drawn automatically for the user, so do not repeat every number; give the headline, the date range, how many weeks have LFL, and any gap in history.',
    input_schema: { type: 'object', properties: { weeks: { type: 'integer', description: 'how many weeks back, default 52, max 156' }, brand: { type: 'string' }, state: { type: 'string' } } } },
  { name: 'show_chart', description: 'Draw a bar or line chart for the user from numbers you already hold (from other tools), e.g. sales by brand, a store\'s weekly sales, state comparison. Use whenever the user asks for a graph, chart, bar graph or trend, or when a picture would clearly help. Do not invent numbers: every value must come from tool results. Up to 60 labels and 4 series. After calling it, add a one- or two-sentence takeaway; do not repeat all the values.',
    input_schema: { type: 'object', properties: { type: { type: 'string', enum: ['bar', 'line'] }, title: { type: 'string' }, unit: { type: 'string', description: 'e.g. "$" or "%"' }, labels: { type: 'array', items: { type: 'string' } }, series: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, values: { type: 'array', items: { type: 'number' } } }, required: ['name', 'values'] } } }, required: ['type', 'title', 'labels', 'series'] } },
  { name: 'store_sales_history', description: 'Weekly sales (and orders/ATV where held) for one store, newest first.',
    input_schema: { type: 'object', properties: { store_id: { type: 'integer' }, weeks: { type: 'integer', description: 'how many weeks, default 13, max 13' } }, required: ['store_id'] } },
  { name: 'rank_stores', description: 'Top or bottom stores by sales for a week, optionally filtered by brand or state. week = "latest" or a week-ending date (YYYY-MM-DD, a Sunday), or 0, -1, -2 for latest, the week before, etc. limit is up to 100 stores (default 10); offset skips that many ranked stores, so a longer list can be read in pages. The result always says total_matching (how many stores fit the filter) and returned, so never say you cannot name stores that are still in the list: ask again with a bigger limit or an offset.',
    input_schema: { type: 'object', properties: { week: { type: 'string' }, brand: { type: 'string' }, state: { type: 'string' }, order: { type: 'string', enum: ['top', 'bottom'] }, limit: { type: 'integer' }, offset: { type: 'integer' } } } },
  { name: 'group_totals', description: 'Total sales for a week grouped by brand, division or state, with change vs the previous week and store counts. Also returns the network total and the report\'s own stated total.',
    input_schema: { type: 'object', properties: { group_by: { type: 'string', enum: ['brand', 'division', 'state'] }, week: { type: 'string' } }, required: ['group_by'] } },
  { name: 'compare_stores', description: 'Side-by-side weekly sales for 2 to 6 stores over the last N weeks.',
    input_schema: { type: 'object', properties: { store_ids: { type: 'array', items: { type: 'integer' } }, weeks: { type: 'integer' } }, required: ['store_ids'] } },
  { name: 'network_events', description: 'Older, coarser list (prefer the pipeline tool for pipeline status, delays, renewals and expiries). Openings, transfers (change of operator), closures, pipeline, franchise-agreement and lease renewal dates from the Network Tracker (2025-26 only). Filter by store_id, brand, or event type keyword (e.g. "Transfer", "Closure", "opening", "expiry").',
    input_schema: { type: 'object', properties: { store_id: { type: 'integer' }, brand: { type: 'string' }, event_type: { type: 'string' }, limit: { type: 'integer' } } } },
  { name: 'pipeline', description: 'The Network Tracker development pipeline (refreshed about every two weeks): new stores being built (greenfield and land-bank "COUS" sites), recently opened stores, transfers (change of operator), closures, franchise-agreement and lease renewals, the activity log, and the C8 lease list. Each site has a status, target and actual dates, days delayed, delay reason and a step-by-step checklist (FP application, location approved, lease signed, franchise docs, fee, design, permits, fitout, training, launch). action: "overview" (counts, as-at date); "list" (filter by kind greenfield/cous/opened/transfer/closure/fa_renewal/lease_renewal, brand, state, status, upcoming_only, limit); "site" (one site by store_id or text, with every step and its activity history); "delayed" (new stores running late, worst first); "expiries" (franchise agreement, lease and C8 lease expiries in the next N months, default 12, plus any already past); "activity" (log of openings, transfers and closures, filter by type, brand, state); "step" (counts and lists sites by one checklist step, e.g. text "Fran Docs Signed" or "Lease Signed" or "Out of Disclosure", with kind/brand/state filters; shows how many sites have each value, where a date counts as "dated"). Questions like "how many sites have X" use step. The tracker records a status word (Completed, Approved, Returned, In Progress, N/A) or sometimes a date for each step; say which it is, and never describe a status word as a date. Always say the latest entry date when the answer is about status, and that the tracker is refreshed about every two weeks; entries after that date are plans.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['overview', 'list', 'site', 'delayed', 'expiries', 'activity', 'step'] }, kind: { type: 'string' }, brand: { type: 'string' }, state: { type: 'string' }, status: { type: 'string' }, text: { type: 'string' }, store_id: { type: 'integer' }, months: { type: 'integer' }, upcoming_only: { type: 'boolean' }, limit: { type: 'integer' } }, required: ['action'] } },
  { name: 'budget', description: 'The FY27 budget (July 2026 to June 2027), compared with FY26 actual. Sections: network_sales, estate_sales_by_brand, store_count, openings (monthly), greenfield, revenue, expense, profit (investment projects, EBITDA, EBIT, NPAT, dividends), marketing_pl (Marketing Concepts, a separate entity), cashflow (monthly), headcount. action: "overview" (what is held and the headline figures), "section" (all lines of a section, optional brand), "find" (search line names, e.g. "royalties", "IT costs", "NPAT"), "notes" (assumptions and commentary; text filters by topic or words, e.g. "greenfield", "acai", "cash"), "vs_actual" (budget run-rate against actual weekly sales by brand since 1 July 2026; approximate). Budget network sales are not on the same basis as weekly Sales Report figures, so say any comparison is approximate.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['overview', 'section', 'find', 'notes', 'vs_actual'] }, section: { type: 'string' }, brand: { type: 'string' }, text: { type: 'string' } }, required: ['action'] } },
  { name: 'org_lookup', description: 'The C8 organisation chart (October FY27): names, positions, departments and who reports to whom. action: "person" (who is X / what is their role / who do they report to), "direct_reports" (who reports to X), "chain_of_command" (X up to the CEO), "department" (everyone in a department or team, e.g. Supply, Legal, Marketing, Ops & Training, Network Development), "role" (who holds a role, e.g. "Head of Finance", "Supply Manager"), "vacancies" (unfilled or recruiting roles). text = the name, role or department. Holds no contact details, addresses or salaries.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['person', 'direct_reports', 'chain_of_command', 'department', 'role', 'vacancies'] }, text: { type: 'string' } }, required: ['action'] } },
  { name: 'daily_sales', description: 'Daily sales (dollars) and orders for each store by trading day, from the Power BI Daily Sales dataset (days held are listed by data_status). Dates are YYYY-MM-DD; "yesterday" or "last Friday" must be turned into a date from the latest day held, which the result reports. This dataset can differ slightly from the weekly Sales Report (a few percent), so say it is the daily figures and never add or compare it with weekly figures as if they were the same. action: "day" (one day, default the latest held: network or scoped sales, orders, ATV, stores trading, against the same weekday last week and the same weekday a year earlier on the stores that traded on both days; scope with brand, state or store_id), "store_days" (one store, day by day, default the last 14 days held; needs store_id; from and to optional), "rank_stores" (rank stores on one day by sales, or by change_vs_last_week or change_vs_last_year; measure; order top or bottom; optional brand, state; limit and offset for more), "range_total" (total for from..to, default the last 7 days held, against the equal-length period just before it; group_by none, brand, state or day; optional brand, state or store_id). Orders are customer orders (sales transactions), not units of items. Days with no row mean the store did not trade or the data is not yet held.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['day', 'store_days', 'rank_stores', 'range_total'] }, date: { type: 'string' }, from: { type: 'string' }, to: { type: 'string' }, store_id: { type: 'integer' }, brand: { type: 'string' }, state: { type: 'string' }, measure: { type: 'string', enum: ['sales', 'change_vs_last_week', 'change_vs_last_year'] }, order: { type: 'string', enum: ['top', 'bottom'] }, group_by: { type: 'string', enum: ['none', 'brand', 'state', 'day'] }, limit: { type: 'integer' }, offset: { type: 'integer' } }, required: ['action'] } },
  { name: 'item_sales', description: 'Menu-item sales (dollars) by store for a multi-week period, from the Power BI Item Sales report (the brands held are listed by data_status and in the result). Virtual brands such as Double Dragon Dumplings and Bokyo trade out of a physical site kitchen (for example Noodle Box - Ashmore or South Seoul - Casey): their item sales are held under their own brand and are a separate figure from the Noodle Box or South Seoul item sales of the same site, so never add the two together as one "site total" and then add that to a brand figure again. action: "top_items" (best-selling items; scope with store_id and/or brand, limit default 10), "item_total" (one item: total and top stores selling it; item = the item name, e.g. "Combination", "Pad Thai"), "item_in_store" (one item at one store, with its rank among that store\'s items; needs store_id and item), "store_items" (a store\'s best-selling items, needs store_id), "rank_stores" (rank stores by item sales for a month or period; optional item to rank by one item; optional state; period_start and period_end pick the month, e.g. 2026-09-01 to 2026-09-30 — use this for "rank the stores in September"). The period is a week or a block of weeks and the result says which; by default it is the latest held, and period_end (YYYY-MM-DD, the last day of a held period) picks another; when several periods share an end date also pass period_start (YYYY-MM-DD). A question about one store automatically uses the latest period that holds that store, longest first. measure: "sales" (dollars, default) or "units" (quantity sold; held only where the result says so). Monthly store-level periods may exist (one month each): use period_start and period_end for the month. Optional state (e.g. VIC) limits to stores in that state. Some periods hold only the top 30 items nationally (the result says partial): then totals and shares are of those items only, never the whole menu. NOT the same basis as the weekly Sales Report, so never compare or add the two. Excludes POS Discount, POS Surcharge, rounding and other adjustment lines unless include_adjustments is true.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['top_items', 'item_total', 'item_in_store', 'store_items', 'rank_stores'] }, item: { type: 'string' }, store_id: { type: 'integer' }, brand: { type: 'string' }, limit: { type: 'integer' }, include_adjustments: { type: 'boolean' }, state: { type: 'string' }, period_end: { type: 'string' }, period_start: { type: 'string' }, measure: { type: 'string', enum: ['sales', 'units'] } }, required: ['action'] } },
  { name: 'finance', description: 'C8 consolidated financial statements from the monthly Finance Board Report PDFs (profit and loss for the month and year to date against budget and last year, balance sheet, bank debt, cash, commentary), for the months listed by data_status or action "overview". Cash flow is DERIVED (the reports have no cash flow statement): action "cash_flow" gives operating cash flow, capital spending, free cash flow before dividend, growth investment, financing and the dividend for one month. action: "overview" (months held, with revenue, operating profit, net income, cash, CBA loan), "month" (headline P&L against budget, YTD, cash, debt, net bank debt for one month), "cash_flow" (month), "lines" (search P&L or balance sheet line names for one month; statement "pl" or "bs"; text e.g. "royalties", "wages", "CBA", "growth facility"), "trend" (one line across all months held; text = line name), "commentary" (the finance team\'s written commentary for a month; text filters). month = "YYYY-MM", default the latest held. All figures AUD as reported; monthly reports can restate the prior month.',
    input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['overview', 'month', 'cash_flow', 'lines', 'trend', 'commentary'] }, month: { type: 'string' }, text: { type: 'string' }, statement: { type: 'string', enum: ['pl', 'bs'] } }, required: ['action'] } },
  { name: 'board_papers', description: 'The monthly board papers (board packs, Finance Board Reports, minutes, agendas) as PDFs: a machine-written summary of each (key points and decisions, with page numbers) and the text of every page for search. Use it for what the board was told, discussed or decided, plans, risks, projects and explanations; NOT for figures (finance tool) or store sales. action: "list" (papers held, optionally one month "YYYY-MM" and/or type), "summary" (one paper by id: summary, key points, decisions, topics), "search" (query = topic words or a phrase; returns matching papers and pages with quoted snippets, optionally for one month or type). type = board_pack | finance_board_report | minutes | agenda. Every result names the file and where the original is kept; say which paper and page you are quoting.', input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'summary', 'search'] }, query: { type: 'string' }, month: { type: 'string', description: 'YYYY-MM' }, type: { type: 'string', enum: ['board_pack', 'finance_board_report', 'minutes', 'agenda'] }, doc_id: { type: 'integer' }, limit: { type: 'integer' } }, required: [] } },
  { name: 'store_agreements', description: 'Franchise agreement and lease details per store, from the SharePoint Franchise Master: ABN, royalty rate, franchise agreement (FA) start/end/options, lease start/end/options, landlord, site size and annual rent. action: "store" (store_id: everything held for one store) or "expiring" (stores whose franchise agreement (kind "fa") or lease (kind "lease") ends within within_months months from today, default 12, including those already past their end date; optional brand and state). Dates are the end dates on record; an end date in the past means the agreement or lease has run out or is being held over, so say that plainly rather than call it expired without checking the options. Only stores in the Franchise Master have these details.', input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['store', 'expiring'] }, store_id: { type: 'integer' }, kind: { type: 'string', enum: ['fa', 'lease'] }, within_months: { type: 'integer' }, brand: { type: 'string' }, state: { type: 'string' }, limit: { type: 'integer' } }, required: ['action'] } },
  { name: 'legal_documents', description: 'Signed franchise agreements and other legal documents held as text (the latest franchise agreement signed by franchisees). Use it for what the document says: clauses on termination, renewal, fees, royalties, transfer, restraint, insurance and so on. action: "list" (documents held), "search" (query = key words; returns matching pages with quoted snippets), "page" (doc_id + page: the whole page text). Quote the clause wording and give document and page. You are not a lawyer: say that this is what the document says, not legal advice, and that the signed original is the reference.', input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'search', 'page'] }, query: { type: 'string' }, doc_id: { type: 'integer' }, page: { type: 'integer' }, limit: { type: 'integer' } }, required: [] } },
  { name: 'manuals', description: 'The C8 operating manuals (Operations Manual, Food Safety Manual, Human Resources Manual, Equipment Manual): the text of every page for search. Use it for how things are done in a restaurant: procedures, food safety, cleaning, equipment, rostering, HR policy. action: "list" (manuals held), "search" (query = key words; returns matching pages with quoted snippets), "page" (doc_id + page: the whole page text). Always name the manual and page you are drawing on.', input_schema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'search', 'page'] }, query: { type: 'string' }, doc_id: { type: 'integer' }, page: { type: 'integer' }, limit: { type: 'integer' } }, required: [] } },
  { name: 'data_status', description: 'What data is held: latest week, weeks available, store counts per brand, last load, and known limitations. Call for questions like "how current is this?" or "what can you tell me?".',
    input_schema: { type: 'object', properties: {} } },
];

// ---- who may use what: every tool belongs to an area; a person's class lists the areas they may use (see auth.js and Admin → Users) ----
const ALL_AREAS = ['sales', 'org', 'finance', 'finance_commentary', 'exec_pay', 'budget', 'board_papers', 'manuals', 'legal'];
const AREA_OF = { show_on_map: 'sales', find_store: 'sales', store_summary: 'sales', stores_by_opening: 'sales', weekly_trend: 'sales', rank_stores_growth: 'sales', show_chart: 'sales', store_sales_history: 'sales', rank_stores: 'sales', group_totals: 'sales', compare_stores: 'sales', network_events: 'sales', pipeline: 'sales', item_sales: 'sales', daily_sales: 'sales',
  org_lookup: 'org', finance: 'finance', budget: 'budget', board_papers: 'board_papers', manuals: 'manuals', store_agreements: 'finance', legal_documents: 'legal' };   // data_status is open to everyone but only describes what the person may use
const EXEC_PAY = /exec|director|\bLTI\b|\bSTI\b|incentive|\bCEO\b|\bCFO\b/i;   // finance lines that show executive or director pay
function defsFor(areas) {
  const a = areas || ALL_AREAS;
  return defs.filter(d => d.name === 'data_status' || a.includes(AREA_OF[d.name])).map(d => {
    if (d.name !== 'finance' || a.includes('finance_commentary')) return d;
    const sch = JSON.parse(JSON.stringify(d.input_schema)); sch.properties.action.enum = sch.properties.action.enum.filter(x => x !== 'commentary');
    return { ...d, input_schema: sch, description: d.description.replace(', commentary)', ')').replace(', "commentary" (the finance team\'s written commentary for a month; text filters)', '') };
  });
}

const impl = {
  async show_on_map({ store_ids }) { const n = (Array.isArray(store_ids) ? store_ids : []).filter(Number.isInteger).length; return { ok: true, stores_shown: n, note: 'The map is now showing these stores to the user.' }; },
  async find_store({ text }) {
    const t = String(text || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!t) return { matches: [] };
    let r = await q(`SELECT DISTINCT s.id, s.name, s.brand, s.state FROM store_aliases a JOIN stores s ON s.id=a.store_id WHERE a.alias=$1 ORDER BY s.brand, s.name`, [t]);
    if (!r.rowCount) r = await q(`SELECT DISTINCT s.id, s.name, s.brand, s.state FROM store_aliases a JOIN stores s ON s.id=a.store_id WHERE a.alias LIKE $1 OR $2 LIKE '%' || a.alias || '%' ORDER BY s.brand, s.name LIMIT 12`, ['%' + t + '%', t]);
    // prefer alias-exact hits with the longest alias when matching by containment
    return { matches: r.rows, note: r.rowCount > 1 ? 'Several stores match; confirm which one if the user did not say the brand.' : undefined };
  },

  async store_summary({ store_id }) {
    const s = (await q(`SELECT *, opening_date::text AS od FROM stores WHERE id=$1`, [store_id])).rows[0]; if (!s) return { error: 'unknown store_id' };
    const h = (await q(`SELECT week_ending::text d, sales, orders, atv FROM weekly_sales WHERE store_id=$1 AND sales IS NOT NULL ORDER BY week_ending DESC LIMIT 13`, [store_id])).rows;
    const lw = await latestWeek(); const cur = h[0]; const prev = h[1];
    const avg = n => { const x = h.slice(0, n); return x.length ? r0(x.reduce((a, b) => a + Number(b.sales), 0) / x.length) : null; };
    let rank = null;
    if (cur && cur.d === lw) {
      const rr = (await q(`SELECT s2.id FROM weekly_sales w JOIN stores s2 ON s2.id=w.store_id WHERE w.week_ending=$1 AND s2.brand=$2 AND w.sales IS NOT NULL ORDER BY w.sales DESC`, [lw, s.brand])).rows.map(x => x.id);
      rank = { position: rr.indexOf(store_id) + 1, of: rr.length, brand: s.brand };
    }
    const od = s.od || null;
    return {
      store: s.name, brand: s.brand, division: s.division, state: s.state, address: s.address, phone: s.phone, trading_company: s.trading_company, bdm: s.bdm,
      opening: od ? { date: od, source: s.opening_date_source, reliability: s.opening_date_confidence } : { date: null, note: 'No opening date on record' },
      latest_week_ending: lw, store_has_latest_week: !!(cur && cur.d === lw),
      latest: cur ? { week_ending: cur.d, sales: r0(cur.sales), orders: cur.orders, atv: r2(cur.atv) } : null,
      previous_week: prev ? { week_ending: prev.d, sales: r0(prev.sales) } : null,
      change_vs_previous_week_pct: cur && prev ? pct(Number(cur.sales), Number(prev.sales)) : null,
      avg_last_4_weeks: avg(4), avg_last_13_weeks: avg(13), weeks_held: h.length, rank_in_brand_latest_week: rank,
    };
  },

  async store_sales_history({ store_id, weeks = 13 }) {
    const n = Math.max(1, Math.min(13, weeks));
    const s = (await q(`SELECT name,brand FROM stores WHERE id=$1`, [store_id])).rows[0]; if (!s) return { error: 'unknown store_id' };
    const r = await q(`SELECT week_ending::text week_ending, sales, orders, atv FROM weekly_sales WHERE store_id=$1 ORDER BY week_ending DESC LIMIT $2`, [store_id, n]);
    return { store: s.name, brand: s.brand, weeks: r.rows.map(x => ({ week_ending: x.week_ending, sales: r0(x.sales), orders: x.orders, atv: r2(x.atv) })), note: 'Orders and ATV are held for the latest week only.' };
  },

  async stores_by_opening({ brand, state, min_years, max_years, limit = 100, offset = 0 }) {
    const n = Math.max(1, Math.min(200, Number(limit) || 100)), off = Math.max(0, Number(offset) || 0);
    const where = `s.active AND ($1::text IS NULL OR s.brand ILIKE '%'||$1||'%') AND ($2::text IS NULL OR upper(s.state)=upper($2))
      AND ($3::numeric IS NULL OR s.opening_date <= current_date - ($3::numeric*365.25)::int) AND ($4::numeric IS NULL OR s.opening_date >= current_date - ($4::numeric*365.25)::int)`;
    const a = [brand || null, state || null, min_years ?? null, max_years ?? null];
    const dated = where + ' AND s.opening_date IS NOT NULL';
    const r = await q(`SELECT s.id, s.name, s.brand, s.state, s.opening_date::text AS opening_date, s.opening_date_source AS source, s.opening_date_confidence AS reliability FROM stores s WHERE ${dated} ORDER BY s.opening_date, s.name LIMIT $5 OFFSET $6`, [...a, n, off]);
    const tot = (await q(`SELECT count(*)::int n, count(*) FILTER (WHERE s.opening_date_confidence ILIKE 'low%')::int low FROM stores s WHERE ${dated}`, a)).rows[0];
    const nodate = Number((await q(`SELECT count(*) n FROM stores s WHERE s.active AND s.opening_date IS NULL AND ($1::text IS NULL OR s.brand ILIKE '%'||$1||'%') AND ($2::text IS NULL OR upper(s.state)=upper($2))`, [a[0], a[1]])).rows[0].n);
    return { total_matching: tot.n, low_reliability_among_matching: tot.low, returned: r.rows.length, more_available: off + r.rows.length < tot.n, stores_with_no_date_on_record: nodate, stores: r.rows,
      note: 'Low reliability = franchise agreement start date only (proxy; the real opening is probably later). Say how many matches are low reliability. Stores with no date on record are not listed.' };
  },

  async show_chart({ type, title, unit, labels, series }) {
    const L = (Array.isArray(labels) ? labels : []).slice(0, 60).map(x => String(x).slice(0, 40));
    const S = (Array.isArray(series) ? series : []).slice(0, 4).map(x => ({ name: String(x.name || '').slice(0, 40), values: L.map((_, i) => { const v = Number((x.values || [])[i]); return Number.isFinite(v) ? v : null; }) }));
    if (!L.length || !S.length) return { error: 'labels and at least one series with values needed' };
    return { ok: true, shown: true, note: 'Chart is now displayed to the user.', _chart: { type: type === 'line' ? 'line' : 'bar', title: String(title || '').slice(0, 120), unit: String(unit || '').slice(0, 4), labels: L, series: S } };
  },

  async rank_stores_growth({ weeks = 13, brand, state, order = 'top', limit = 10, offset = 0 }) {
    const n = Math.max(4, Math.min(52, Number(weeks) || 13)); const latest = await resolveWeek(); const lim = Math.max(1, Math.min(100, Number(limit) || 10)); const off = Math.max(0, Number(offset) || 0);
    const need = Math.max(4, n - 1);
    const rows = (await q(`WITH cur AS (SELECT w.store_id, w.week_ending, w.sales FROM weekly_sales w WHERE w.week_ending > $1::date - ($2::int*7) AND w.week_ending <= $1::date AND w.sales > 0),
      pairs AS (SELECT c.store_id, c.sales cs, p.sales ps FROM cur c JOIN weekly_sales p ON p.store_id=c.store_id AND p.week_ending=c.week_ending-364 AND p.sales > 0),
      agg AS (SELECT store_id, count(*)::int wks, sum(cs) cur, sum(ps) prior FROM pairs GROUP BY 1),
      s1 AS (SELECT store_id, count(*)::int cw FROM cur GROUP BY 1)
      SELECT s.id, s.name, s.brand, s.state, s.opening_date::text od, s.opening_date_confidence odc, ($1::date - ($2::int*7) - 364 - 91 < s.opening_date) AS ramp, a.wks, a.cur, a.prior, s1.cw FROM stores s JOIN s1 ON s1.store_id=s.id LEFT JOIN agg a ON a.store_id=s.id
      WHERE ($3::text IS NULL OR s.brand ILIKE '%'||$3||'%') AND ($4::text IS NULL OR upper(s.state)=upper($4))`, [latest, n, brand || null, state || null])).rows;
    const ok = rows.filter(r => r.wks >= need && r.prior > 0).map(r => ({ store_id: r.id, store: r.name, brand: r.brand, state: r.state, weeks_compared: r.wks, sales_this_year: r0(r.cur), sales_same_weeks_last_year: r0(r.prior), growth_pct: pct(Number(r.cur), Number(r.prior)), opening_date: r.od || undefined, caution: r.ramp ? 'opened shortly before or during the prior-year weeks, so last year was its ramp-up and growth is flattered' : undefined }));
    ok.sort((a, b) => order === 'bottom' ? a.growth_pct - b.growth_pct : b.growth_pct - a.growth_pct);
    const out = ok.slice(off, off + lim).map((x, i) => ({ rank: off + i + 1, ...x }));
    const excluded = rows.length - ok.length;
    return { period: `last ${n} weeks to ${latest}, vs the same weeks a year earlier`, rule: `stores need at least ${need} of ${n} weeks trading in both years; newer stores are excluded`, total_ranked: ok.length, excluded_new_or_short_history: excluded, returned: out.length, offset: off, more_available: off + out.length < ok.length ? `${ok.length - off - out.length} more: call again with offset ${off + out.length}` : undefined, results: out, stores_with_ramp_up_caution: ok.filter(x => x.caution).length,
      note: state ? 'State is only recorded for stores matched to the SharePoint list, so a state filter may miss stores.' : undefined };
  },

  async weekly_trend({ weeks = 52, brand, state }) {
    const n = Math.max(1, Math.min(156, Number(weeks) || 52)); const latest = await resolveWeek();
    // Power BI's own like-for-like % (loaded from its LFL Weekly Trend page) is the company's official figure: use it when held
    const scope = brand || state || 'All';
    const pb = (await q(`WITH m AS (SELECT max(week_ending) d FROM company_weekly WHERE lower(scope)=lower($1)) SELECT c.week_ending::text wk, c.lfl_pct, c.source FROM company_weekly c, m WHERE lower(c.scope)=lower($1) AND c.week_ending > m.d - ($2::int*7) ORDER BY 1`, [scope, n])).rows;
    if (pb.length >= 4) {
      const have = (await q(`SELECT w.week_ending::text wk, sum(w.sales) total, count(*) FILTER (WHERE w.sales>0)::int stores FROM weekly_sales w JOIN stores s ON s.id=w.store_id WHERE w.week_ending = ANY($1::date[]) AND ($2::text IS NULL OR s.brand ILIKE '%'||$2||'%') AND ($3::text IS NULL OR upper(s.state)=upper($3)) GROUP BY 1`, [pb.map(x => x.wk), brand || null, state || null])).rows;
      const sm = new Map(have.map(x => [x.wk, x])); const vals = pb.map(x => Number(x.lfl_pct));
      return { source: 'Power BI "LFL Weekly Trend" (Site LFL % = company like-for-like sales growth vs the same week last year)', scope, weeks_returned: pb.length, first_week: pb[0].wk, last_week: pb.at(-1).wk, average_lfl_pct: Math.round(vals.reduce((a, b) => a + b, 0) / vals.length * 100) / 100, weeks_negative: vals.filter(v => v < 0).length,
        best_week: pb.reduce((a, b) => (Number(b.lfl_pct) > Number(a.lfl_pct) ? b : a)), worst_week: pb.reduce((a, b) => (Number(b.lfl_pct) < Number(a.lfl_pct) ? b : a)),
        weeks: pb.map(x => ({ week_ending: x.wk, lfl_growth_pct: Number(x.lfl_pct), total_sales: sm.has(x.wk) ? r0(sm.get(x.wk).total) : null, stores_trading: sm.has(x.wk) ? sm.get(x.wk).stores : null })),
        note: 'These are Power BI\'s own like-for-like figures, so quote them as such. Total sales are shown only for weeks the app holds store sales for.',
        _chart: { type: 'bar', title: `Like-for-like sales growth % by week${scope !== 'All' ? ' · ' + scope : ' · whole company'} (Power BI Site LFL)`, unit: '%', labels: pb.map(x => x.wk.slice(5).split('-').reverse().join('/')), series: [{ name: 'LFL % vs same week last year', values: vals }] } };
    }
    const hist = (await q(`SELECT min(week_ending)::text f, count(DISTINCT week_ending)::int n FROM weekly_sales`)).rows[0];
    const r = await q(`SELECT c.week_ending::text wk, sum(c.sales) total, count(*) FILTER (WHERE c.sales>0)::int stores,
        sum(c.sales) FILTER (WHERE c.sales>0 AND p.sales>0) lfl_cur, sum(p.sales) FILTER (WHERE c.sales>0 AND p.sales>0) lfl_prior, count(*) FILTER (WHERE c.sales>0 AND p.sales>0)::int lfl_stores
      FROM weekly_sales c JOIN stores s ON s.id=c.store_id LEFT JOIN weekly_sales p ON p.store_id=c.store_id AND p.week_ending=c.week_ending-364
      WHERE c.week_ending > $1::date - ($2::int*7) AND c.week_ending <= $1::date AND ($3::text IS NULL OR s.brand ILIKE '%'||$3||'%') AND ($4::text IS NULL OR upper(s.state)=upper($4))
      GROUP BY 1 ORDER BY 1`, [latest, n, brand || null, state || null]);
    const rows = r.rows.map(x => ({ week_ending: x.wk, total_sales: r0(x.total), stores_trading: x.stores, lfl_sales: r0(x.lfl_cur), lfl_prior_year_sales: r0(x.lfl_prior), lfl_stores: x.lfl_stores, lfl_growth_pct: pct(Number(x.lfl_cur), Number(x.lfl_prior)) }));
    const withLfl = rows.filter(x => x.lfl_growth_pct !== null);
    const lbl = rows.map(x => x.week_ending.slice(5).split('-').reverse().join('/'));
    const chart = withLfl.length
      ? { type: 'bar', title: `Like-for-like weekly sales${brand ? ' · ' + brand : ' · all brands'} (stores trading both years)`, unit: '$', labels: withLfl.map(x => x.week_ending.slice(5).split('-').reverse().join('/')), series: [{ name: 'This year', values: withLfl.map(x => x.lfl_sales) }, { name: 'Same stores last year', values: withLfl.map(x => x.lfl_prior_year_sales) }] }
      : { type: 'bar', title: `Total weekly sales${brand ? ' · ' + brand : ' · all brands'}`, unit: '$', labels: lbl, series: [{ name: 'Total sales', values: rows.map(x => x.total_sales) }] };
    return { requested_weeks: n, weeks_returned: rows.length, first_week: rows[0]?.week_ending || null, last_week: rows.at(-1)?.week_ending || null, weeks_of_history_held: hist.n, history_starts: hist.f,
      weeks_with_lfl: withLfl.length, definition: 'LFL = stores with sales in both the week and the same week a year earlier (364 days); growth compares this year with those same stores last year.',
      note: withLfl.length === 0 ? 'No year-earlier weeks are held yet, so like-for-like cannot be calculated; total sales and store counts are shown instead (store count changes make totals not like-for-like). Tell the user history needs loading (Admin → Upload weekly sales) to get LFL.' : (withLfl.length < rows.length ? 'Some weeks have no year-earlier comparison, so only ' + withLfl.length + ' weeks show LFL.' : undefined),
      weeks: rows, _chart: chart };
  },

  async rank_stores({ week, brand, state, order = 'top', limit = 10, offset = 0 }) {
    const d = await resolveWeek(week); const n = Math.max(1, Math.min(100, Number(limit) || 10)); const off = Math.max(0, Number(offset) || 0);
    const r = await q(`SELECT s.id, s.name, s.brand, s.state, w.sales, w.orders, w.atv FROM weekly_sales w JOIN stores s ON s.id=w.store_id
      WHERE w.week_ending=$1 AND w.sales IS NOT NULL AND ($2::text IS NULL OR s.brand ILIKE '%'||$2||'%') AND ($3::text IS NULL OR s.state=upper($3))
      ORDER BY w.sales ${order === 'bottom' ? 'ASC' : 'DESC'}, s.name LIMIT $4 OFFSET $5`, [d, brand || null, state || null, n, off]);
    const tot = Number((await q(`SELECT count(*) n FROM weekly_sales w JOIN stores s ON s.id=w.store_id WHERE w.week_ending=$1 AND w.sales IS NOT NULL AND ($2::text IS NULL OR s.brand ILIKE '%'||$2||'%') AND ($3::text IS NULL OR s.state=upper($3))`, [d, brand || null, state || null])).rows[0].n);
    return { week_ending: d, order, total_matching: tot, returned: r.rows.length, offset: off, more_available: off + r.rows.length < tot ? `${tot - off - r.rows.length} more stores: call again with offset ${off + r.rows.length}` : undefined, results: r.rows.map((x, i) => ({ rank: off + i + 1, store_id: x.id, store: x.name, brand: x.brand, state: x.state, sales: r0(x.sales), orders: x.orders, atv: r2(x.atv) })),
      note: state ? 'State is only recorded for stores matched to the SharePoint list, so a state filter may miss stores.' : undefined };
  },

  async group_totals({ group_by, week }) {
    const col = { brand: 's.brand', division: 's.division', state: "COALESCE(s.state,'(state not recorded)')" }[group_by]; if (!col) return { error: 'bad group_by' };
    const d = await resolveWeek(week);
    const prevD = (await q(`SELECT max(week_ending)::text d FROM weekly_sales WHERE week_ending < $1`, [d])).rows[0].d;
    const r = await q(`SELECT ${col} g, sum(CASE WHEN w.week_ending=$1 THEN w.sales END) cur, sum(CASE WHEN w.week_ending=$2 THEN w.sales END) prev,
        count(DISTINCT CASE WHEN w.week_ending=$1 AND w.sales IS NOT NULL THEN s.id END) stores
      FROM weekly_sales w JOIN stores s ON s.id=w.store_id WHERE w.week_ending IN ($1,$2) GROUP BY 1 ORDER BY cur DESC NULLS LAST`, [d, prevD]);
    const rep = (await q(`SELECT report_total FROM weekly_totals WHERE week_ending=$1`, [d])).rows[0];
    const sum = r.rows.reduce((a, b) => a + Number(b.cur || 0), 0);
    return { week_ending: d, previous_week_ending: prevD, groups: r.rows.map(x => ({ group: x.g, sales: r0(x.cur), previous_week_sales: r0(x.prev), change_pct: pct(Number(x.cur), Number(x.prev)), stores_trading: Number(x.stores) })),
      sum_of_stores: r0(sum), report_stated_total: rep ? r0(rep.report_total) : null };
  },

  async compare_stores({ store_ids, weeks = 8 }) {
    const ids = (store_ids || []).slice(0, 6); const n = Math.max(1, Math.min(13, weeks));
    const out = [];
    for (const id of ids) { const s = (await q(`SELECT name,brand FROM stores WHERE id=$1`, [id])).rows[0]; if (!s) continue;
      const h = (await q(`SELECT week_ending::text d, sales FROM weekly_sales WHERE store_id=$1 ORDER BY week_ending DESC LIMIT $2`, [id, n])).rows;
      out.push({ store_id: id, store: s.name, brand: s.brand, weeks: h.map(x => ({ week_ending: x.d, sales: r0(x.sales) })) }); }
    return { stores: out };
  },

  async network_events({ store_id, brand, event_type, limit = 30 }) {
    const r = await q(`SELECT source, brand, restaurant, state, event_type, event_date, date_meaning, note FROM network_events
      WHERE ($1::int IS NULL OR store_id=$1) AND ($2::text IS NULL OR brand ILIKE '%'||$2||'%') AND ($3::text IS NULL OR event_type ILIKE '%'||$3||'%')
      ORDER BY event_date NULLS LAST LIMIT $4`, [store_id || null, brand || null, event_type || null, Math.min(60, limit)]);
    return { events: r.rows, note: 'Source is the Network Tracker workbook (2025 and early 2026 only). Some forecast dates were never updated.' };
  },

  async daily_sales(inp) {
    const iso = v => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : null);
    const latest = (await q(`SELECT max(sales_date)::text d, min(sales_date)::text mn, count(DISTINCT sales_date) n FROM daily_sales`)).rows[0];
    if (!latest.d) return { error: 'No daily sales are held yet.' };
    const { action = 'day', brand = null, state = null } = inp; const sid = Number.isInteger(inp.store_id) ? inp.store_id : null;
    const scope = `($2::text IS NULL OR s.brand ILIKE '%'||$2||'%') AND ($3::text IS NULL OR s.state=upper($3)) AND ($4::int IS NULL OR s.id=$4)`;
    const sargs = [brand || null, state || null, sid];
    const head = { latest_day_held: latest.d, days_held: Number(latest.n), earliest_day_held: latest.mn, source: 'Daily Sales dataset' };
    const addDays = (d, n) => new Date(Date.parse(d + 'T00:00:00Z') + n * 86400000).toISOString().slice(0, 10);
    const wd = async d => (await q(`SELECT to_char($1::date,'FMDay') w`, [d])).rows[0].w;
    const cmp = (cur, prev) => (prev ? pct(cur, prev) : null);
    if (action === 'day') {
      const d = iso(inp.date) || latest.d, lw = addDays(d, -7), ly = addDays(d, -364);
      const r = (await q(`WITH c AS (SELECT ds.store_id, ds.sales, ds.orders FROM daily_sales ds JOIN stores s ON s.id=ds.store_id WHERE ds.sales_date=$1 AND ${scope}),
          l AS (SELECT ds.store_id, ds.sales FROM daily_sales ds WHERE ds.sales_date=$5), y AS (SELECT ds.store_id, ds.sales FROM daily_sales ds WHERE ds.sales_date=$6)
        SELECT count(*) stores, sum(c.sales) cur, sum(c.orders) FILTER (WHERE c.orders IS NOT NULL) orders, count(c.orders) n_orders,
          count(l.store_id) n_lw, sum(l.sales) lw, sum(c.sales) FILTER (WHERE l.store_id IS NOT NULL) cur_lw,
          count(y.store_id) n_ly, sum(y.sales) ly, sum(c.sales) FILTER (WHERE y.store_id IS NOT NULL) cur_ly
        FROM c LEFT JOIN l ON l.store_id=c.store_id LEFT JOIN y ON y.store_id=c.store_id`, [d, ...sargs, lw, ly])).rows[0];
      if (!Number(r.stores)) return { ...head, date: d, weekday: await wd(d), stores_trading: 0, note: 'No sales are held for that day with that scope.' };
      return { ...head, date: d, weekday: await wd(d), scope: { brand, state, store_id: sid }, stores_trading: Number(r.stores), sales: r0(r.cur), orders: Number(r.n_orders) ? Number(r.orders) : null, atv: Number(r.n_orders) && Number(r.orders) ? r2(Number(r.cur) / Number(r.orders)) : null,
        vs_same_weekday_last_week: Number(r.n_lw) ? { date: lw, stores_compared: Number(r.n_lw), sales_this_day_same_stores: r0(r.cur_lw), sales_that_day: r0(r.lw), change_pct: cmp(Number(r.cur_lw), Number(r.lw)) } : 'no data held for ' + lw,
        vs_same_weekday_last_year: Number(r.n_ly) ? { date: ly, stores_compared: Number(r.n_ly), sales_this_day_same_stores: r0(r.cur_ly), sales_that_day: r0(r.ly), change_pct: cmp(Number(r.cur_ly), Number(r.ly)) } : 'no data held for ' + ly + ' (a year of daily history is not held yet)',
        note: 'Changes compare only stores that traded on both days, so new and closed stores do not distort them.' };
    }
    if (action === 'store_days') {
      if (!sid) return { error: 'store_days needs a store_id (use find_store first)' };
      const to = iso(inp.to) || latest.d, from = iso(inp.from) || addDays(to, -13);
      const r = await q(`SELECT ds.sales_date::text d, to_char(ds.sales_date,'FMDay') w, ds.sales, ds.orders, (SELECT l.sales FROM daily_sales l WHERE l.store_id=ds.store_id AND l.sales_date=ds.sales_date-7) lw
        FROM daily_sales ds WHERE ds.store_id=$1 AND ds.sales_date BETWEEN $2 AND $3 ORDER BY ds.sales_date`, [sid, from, to]);
      const st = (await q(`SELECT name, brand FROM stores WHERE id=$1`, [sid])).rows[0]; if (!st) return { error: 'unknown store_id' };
      return { ...head, store: st.name, brand: st.brand, from, to, days: r.rows.map(x => ({ date: x.d, weekday: x.w, sales: r0(x.sales), orders: x.orders, atv: x.orders ? r2(Number(x.sales) / x.orders) : null, same_weekday_last_week: r0(x.lw), change_pct: cmp(Number(x.sales), Number(x.lw)) })),
        total_sales: r0(r.rows.reduce((a, x) => a + Number(x.sales), 0)), days_with_sales: r.rowCount };
    }
    if (action === 'rank_stores') {
      const d = iso(inp.date) || latest.d, n = Math.max(1, Math.min(100, Number(inp.limit) || 10)), off = Math.max(0, Number(inp.offset) || 0), asc = inp.order === 'bottom';
      const m = ['change_vs_last_week', 'change_vs_last_year'].includes(inp.measure) ? inp.measure : 'sales'; const back = m === 'change_vs_last_year' ? 364 : 7;
      const r = await q(`SELECT s.id, s.name, s.brand, s.state, c.sales, c.orders, p.sales prev, CASE WHEN p.sales > 0 THEN (c.sales/p.sales-1)*100 END chg
        FROM daily_sales c JOIN stores s ON s.id=c.store_id LEFT JOIN daily_sales p ON p.store_id=c.store_id AND p.sales_date=c.sales_date-$5::int
        WHERE c.sales_date=$1 AND ${scope} AND ($6='sales' OR p.sales > 0)
        ORDER BY ${m === 'sales' ? 'c.sales' : 'chg'} ${asc ? 'ASC' : 'DESC'} NULLS LAST, s.name LIMIT $7 OFFSET $8`, [d, ...sargs, back, m, n, off]);
      const tot = Number((await q(`SELECT count(*) n FROM daily_sales c JOIN stores s ON s.id=c.store_id LEFT JOIN daily_sales p ON p.store_id=c.store_id AND p.sales_date=c.sales_date-$5::int WHERE c.sales_date=$1 AND ${scope} AND ($6='sales' OR p.sales > 0)`, [d, ...sargs, back, m])).rows[0].n);
      return { ...head, date: d, weekday: await wd(d), measure: m, order: asc ? 'bottom' : 'top', total_matching: tot, returned: r.rowCount, offset: off, more_available: off + r.rowCount < tot ? `${tot - off - r.rowCount} more stores: call again with offset ${off + r.rowCount}` : undefined,
        results: r.rows.map((x, i) => ({ rank: off + i + 1, store_id: x.id, store: x.name, brand: x.brand, state: x.state, sales: r0(x.sales), orders: x.orders, ...(m === 'sales' ? {} : { comparison_day_sales: r0(x.prev), change_pct: x.chg == null ? null : Math.round(Number(x.chg) * 10) / 10 }) })),
        note: (state ? 'State is only recorded for stores matched to the SharePoint list, so a state filter may miss stores. ' : '') + (m === 'sales' ? '' : 'Only stores that traded on both days are ranked.') || undefined };
    }
    if (action === 'range_total') {
      const to = iso(inp.to) || latest.d, from = iso(inp.from) || addDays(to, -6); const len = Math.round((Date.parse(to) - Date.parse(from)) / 86400000) + 1;
      if (len < 1 || len > 400) return { error: 'from must be on or before to, within 400 days' };
      const pTo = addDays(from, -1), pFrom = addDays(pTo, -(len - 1));
      const gb = ['brand', 'state', 'day'].includes(inp.group_by) ? inp.group_by : 'none'; const col = { none: "'all'", brand: 's.brand', state: "COALESCE(s.state,'(state not recorded)')", day: 'ds.sales_date::text' }[gb];
      const r = await q(`SELECT ${col} g, sum(CASE WHEN ds.sales_date BETWEEN $1 AND $2 THEN ds.sales END) cur, sum(CASE WHEN ds.sales_date BETWEEN $1 AND $2 THEN ds.orders END) orders,
          count(DISTINCT CASE WHEN ds.sales_date BETWEEN $1 AND $2 THEN ds.store_id END) stores, count(DISTINCT CASE WHEN ds.sales_date BETWEEN $1 AND $2 THEN ds.sales_date END) days,
          sum(CASE WHEN ds.sales_date BETWEEN $3 AND $4 THEN ds.sales END) prev, count(DISTINCT CASE WHEN ds.sales_date BETWEEN $3 AND $4 THEN ds.sales_date END) prev_days
        FROM daily_sales ds JOIN stores s ON s.id=ds.store_id
        WHERE ds.sales_date BETWEEN $3 AND $2 AND ($5::text IS NULL OR s.brand ILIKE '%'||$5||'%') AND ($6::text IS NULL OR s.state=upper($6)) AND ($7::int IS NULL OR s.id=$7)
        GROUP BY 1 ORDER BY ${gb === 'day' ? '1' : 'cur DESC NULLS LAST'}`, [from, to, pFrom, pTo, ...sargs]);
      const groups = r.rows.filter(x => Number(x.cur) || gb !== 'day').map(x => ({ group: x.g, sales: r0(x.cur), orders: x.orders == null ? null : Number(x.orders), stores_trading: Number(x.stores), days_with_data: Number(x.days),
        ...(gb === 'day' ? {} : { previous_period_sales: r0(x.prev), change_pct: Number(x.prev_days) === Number(x.days) ? cmp(Number(x.cur), Number(x.prev)) : null }) }));
      return { ...head, from, to, days_in_range: len, previous_period: { from: pFrom, to: pTo }, group_by: gb, groups: groups.slice(0, 70),
        note: 'The change compares with the equal-length period just before, on all stores that traded in each (not same-store), and is left out where the days held differ. Use the day action for same-store comparisons.' };
    }
    return { error: 'unknown action' };
  },

  async item_sales({ action = 'top_items', item, store_id, brand, limit = 10, include_adjustments = false, state, period_end, period_start, measure }) {
    const needStores = !!store_id || !!state || ['rank_stores', 'item_total', 'item_in_store', 'store_items'].includes(action);
    const col = String(measure || '').toLowerCase().startsWith('unit') ? 'units' : 'sales'; const unitsQ = col === 'units';
    const per = (await q(`SELECT brand, period_start::text ps, period_end::text pe, count(DISTINCT store_name) stores, count(DISTINCT item_name) items, (store_name='All stores (brand total)') bt, count(units) nu FROM item_sales GROUP BY 1,2,3,6 ORDER BY max(period_end) DESC, (max(period_end) - min(period_start)) ASC, bt DESC`)).rows;
    if (!per.length) return { error: 'No item sales have been loaded yet.' };
    let b = brand ? (per.find(p => p.brand.toLowerCase().includes(String(brand).toLowerCase())) || {}).brand : null; let sName = null; let otherBrands = [];
    if (store_id) { const s = (await q(`SELECT name, brand FROM stores WHERE id=$1`, [store_id])).rows[0]; if (!s) return { error: 'unknown store_id' }; sName = s.name; b = b || s.brand;
      // a store question with no brand named: use the store's own brand, but if it has no item rows there fall back to the brand (e.g. a virtual brand) that does
      if (!brand) { const hb = (await q(`SELECT brand, count(*) n FROM item_sales WHERE store_id=$1 GROUP BY 1 ORDER BY n DESC`, [store_id])).rows; if (hb.length && !hb.some(h => h.brand === b)) b = hb[0].brand; otherBrands = hb.filter(h => h.brand !== b).map(h => h.brand); } }
    if (brand && !b) return { error: 'No item sales are held for that brand. Held: ' + [...new Set(per.map(p => p.brand))].join(', ') };
    let cands = per.filter(p => !b || p.brand === b); if (period_end) { cands = cands.filter(p => p.pe === String(period_end).slice(0, 10)); if (!cands.length) return { error: 'No item sales period ends on ' + period_end + '. Held: ' + per.filter(p => !b || p.brand === b).slice(0, 10).map(p => p.ps + ' to ' + p.pe).join('; ') }; }
    if (period_start) { cands = cands.filter(p => p.ps === String(period_start).slice(0, 10)); if (!cands.length) return { error: 'No item sales period starts on ' + period_start + '. Held: ' + per.filter(p => !b || p.brand === b).slice(0, 10).map(p => p.ps + ' to ' + p.pe).join('; ') }; }
    if (needStores) { const nb = cands.filter(p => !p.bt); if (nb.length) cands = nb; }
    // a store-scoped question needs a period that actually holds that store (brand-total periods hold none); prefer the longest such period
    if ((store_id || state) && !period_end && !period_start) {
      const have = (await q(`SELECT brand, period_start::text ps, period_end::text pe, count(*) n FROM item_sales WHERE ($1::int IS NULL OR store_id=$1) AND ($2::text IS NULL OR store_id IN (SELECT id FROM stores WHERE upper(state)=upper($2))) AND store_id IS NOT NULL GROUP BY 1,2,3`, [store_id || null, state ? String(state).trim() : null])).rows;
      const ok = cands.filter(p => !p.bt && have.some(h => h.brand === p.brand && h.ps === p.ps && h.pe === p.pe));
      if (ok.length) cands = ok.sort((x, y) => (x.pe < y.pe ? 1 : x.pe > y.pe ? -1 : (new Date(y.pe) - new Date(y.ps)) - (new Date(x.pe) - new Date(x.ps))));
    }
    if (unitsQ) { const w = cands.filter(p => Number(p.nu) > 0); if (!w.length) return { error: 'No unit counts are held for ' + (b || 'that brand') + '. Only dollars are held, so say units are not available.' }; if (!period_end && !period_start) cands = w; else if (!w.some(p => cands.includes(p))) return { error: 'No unit counts are held for that period. Periods with units: ' + per.filter(p => Number(p.nu) > 0 && (!b || p.brand === b)).slice(0, 12).map(p => p.ps + ' to ' + p.pe).join('; ') }; }
    const pr = cands[0]; if (!pr) return { error: 'No item sales held for ' + b };
    if (pr.bt && needStores) return { error: 'The ' + pr.ps + ' to ' + pr.pe + ' item sales for ' + pr.brand + ' are brand totals only (all stores combined, not split by store), so they cannot be broken down by store or state. Periods that are split by store: ' + (per.filter(p => p.brand === pr.brand && !p.bt).map(p => p.ps + ' to ' + p.pe).join('; ') || 'none') + '. Say so plainly; do not guess which store the figures belong to.' };
    let stIds = null; if (state) { stIds = (await q(`SELECT id FROM stores WHERE upper(state)=upper($1) AND active`, [String(state).trim()])).rows.map(r => r.id); if (!stIds.length) return { error: 'No stores are held for state ' + state }; }
    const n = Math.max(1, Math.min(25, Number(limit) || 10));
    const ADJ = `lower(item_name) NOT IN ('pos discount','pos surcharge','sale rounding','dynamic plu instruction')`;
    const base = `FROM item_sales WHERE brand=$1 AND period_start=$2 AND period_end=$3 AND (store_name='All stores (brand total)') = ${pr.bt ? 'true' : 'false'} AND ($4::int IS NULL OR store_id=$4) ${stIds ? 'AND store_id IN (' + stIds.map(Number).join(',') + ')' : ''} ${include_adjustments ? '' : 'AND ' + ADJ}`;
    const args = [pr.brand, pr.ps, pr.pe, store_id || null];
    const meta = { brand: pr.brand, period: pr.ps + ' to ' + pr.pe, stores_in_report: Number(pr.stores), scope: sName || (state ? String(state).toUpperCase() + ' ' : 'all ') + pr.brand + ' stores in the report', items_in_period: Number(pr.items), available_periods: per.filter(p => p.brand === pr.brand).slice(0, 8).map(p => p.ps + ' to ' + p.pe + (p.bt ? ' (brand total, not split by store)' : '') + (Number(p.items) <= 35 ? ' (top ' + p.items + ' items only)' : '')), ...(pr.bt ? { brand_total_only: true, note: 'All stores combined; this is the whole brand, NOT a single store.' } : {}), ...(Number(pr.items) <= 35 ? { partial: true, caution: 'This period holds only the top ' + pr.items + ' items nationally, so totals and shares are of those items, not the whole menu.' } : {}), ...(otherBrands.length ? { also_held_for_this_store: otherBrands, note_other_brands: 'This store also has item sales under: ' + otherBrands.join(', ') + '. Ask with that brand named to see them; they are separate figures.' } : {}), measure: unitsQ ? 'units (quantity sold)' : 'dollars', basis: 'Item Sales report, ' + (unitsQ ? 'units sold' : 'dollars') + '. Not on the same basis as the weekly Sales Report; do not compare them.' };
    const r2n = v => Math.round(Number(v) * 100) / 100;
    if (action === 'rank_stores') {
      const rows = (await q(`SELECT store_name, max(store_id) sid, sum(${col}) s ${base} ${item ? "AND item_name ILIKE '%'||$5||'%'" : ''} GROUP BY store_name HAVING sum(${col}) > 0 ORDER BY s DESC LIMIT 150`, item ? [...args, item.trim()] : args)).rows;
      if (!rows.length) return { ...meta, error: item ? 'No store sold an item matching "' + item + '" in this period.' : 'No store rows in this period.' };
      const tot = rows.reduce((a2, x) => a2 + Number(x.s), 0);
      return { ...meta, ranked_by: (item ? 'item "' + item + '" ' : 'all held items ') + (unitsQ ? 'units' : 'dollars'), caution: 'Store-level files hold only the top items per brand, so this ranks stores by those items, not by their total sales (use the weekly Sales Report tools for total sales).', stores_ranked: rows.length, total: r2n(tot), ranking: rows.map((x, i) => ({ rank: i + 1, store: x.store_name, [unitsQ ? 'units' : 'sales']: r2n(x.s), share_pct: Math.round(x.s / tot * 1000) / 10 })) };
    }
    if (action === 'top_items' || action === 'store_items') {
      if (action === 'store_items' && !store_id) return { error: 'store_items needs store_id' };
      const rows = (await q(`SELECT item_name, sum(${col}) s ${base} GROUP BY item_name HAVING sum(${col}) > 0 ORDER BY s DESC LIMIT ${n}`, args)).rows;
      const tot = (await q(`SELECT sum(${col}) s ${base}`, args)).rows[0].s;
      return { ...meta, [unitsQ ? 'total_item_units' : 'total_item_sales']: r2n(tot), items: rows.map(x => ({ item: x.item_name, [unitsQ ? 'units' : 'sales']: r2n(x.s), share_pct: Math.round(x.s / tot * 1000) / 10 })) };
    }
    if (!item) return { error: 'item is required' };
    let names = (await q(`SELECT DISTINCT item_name ${base} AND lower(item_name)=lower($5)`, [...args, item.trim()])).rows.map(x => x.item_name);
    if (!names.length) names = (await q(`SELECT item_name, sum(${col}) s ${base} AND item_name ILIKE '%'||$5||'%' GROUP BY 1 ORDER BY s DESC LIMIT 6`, [...args, item.trim()])).rows.map(x => x.item_name);
    if (!names.length) return { ...meta, error: 'No item matching "' + item + '" in this report.' };
    if (names.length > 1) return { ...meta, ambiguous_items: names, note: 'Several items match; ask which one, or use the exact name.' };
    const it = names[0]; const a2 = [...args, it];
    if (action === 'item_total') {
      const tot = (await q(`SELECT sum(${col}) s, count(DISTINCT store_name) FILTER (WHERE ${col} > 0) n ${base} AND item_name=$5`, a2)).rows[0];
      const top = (await q(`SELECT store_name, sum(${col}) s ${base} AND item_name=$5 GROUP BY 1 ORDER BY s DESC LIMIT ${n}`, a2)).rows;
      return { ...meta, item: it, [unitsQ ? 'total_units' : 'total_sales']: r2n(tot.s), stores_selling: Number(tot.n), top_stores: top.map(x => ({ store: x.store_name, [unitsQ ? 'units' : 'sales']: r2n(x.s) })) };
    }
    if (action === 'item_in_store') {
      if (!store_id) return { error: 'item_in_store needs store_id' };
      const mine = (await q(`SELECT sum(${col}) s ${base} AND item_name=$5`, a2)).rows[0].s;
      const rk = (await q(`SELECT item_name, sum(${col}) s ${base} GROUP BY 1 HAVING sum(${col}) > 0 ORDER BY s DESC`, args)).rows;
      const pos = rk.findIndex(x => x.item_name === it);
      const tot = rk.reduce((a, x) => a + Number(x.s), 0);
      return { ...meta, item: it, store: sName, [unitsQ ? 'units' : 'sales']: r2n(mine || 0), rank_in_store: pos >= 0 ? pos + 1 : null, of_items: rk.length, share_of_store_item_sales_pct: tot ? Math.round(Number(mine || 0) / tot * 1000) / 10 : null };
    }
    return { error: 'unknown action' };
  },

  async org_lookup({ action = 'person', text = '' }) {
    const all = (await q(`SELECT id,name,position,department,team,parent_id,kind,chart_group,status_flag,region,notes,reports_to_basis basis FROM people ORDER BY id`)).rows;
    if (!all.length) return { error: 'No organisation chart has been loaded yet.' };
    const by = new Map(all.map(p => [p.id, p])); const kids = new Map(); for (const p of all) if (p.parent_id) kids.set(p.parent_id, [...(kids.get(p.parent_id) || []), p]);
    const nm = s => String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim(); const t = nm(text);
    const label = p => p.kind === 'vacant' ? `Vacant: ${p.position}` : p.name;
    const brief = p => ({ name: p.kind === 'vacant' ? null : p.name, position: p.position, department: p.department, team: p.team, vacant: p.kind === 'vacant' ? true : undefined, flag: p.status_flag || undefined });
    const full = p => { const boss = by.get(p.parent_id); const dr = kids.get(p.id) || []; return { ...brief(p), region: p.region || undefined, reports_to: boss ? { name: label(boss), position: boss.position } : null, how_reporting_line_is_known: p.basis || undefined, direct_reports: dr.map(d => `${label(d)} (${d.position})`), note: p.notes || undefined }; };
    const nameHits = () => all.filter(p => p.kind !== 'vacant' && t && (nm(p.name) === t || nm(p.name).includes(t) || t.split(' ').filter(w => w.length > 2).every(w => nm(p.name).includes(w)) && t.split(' ').filter(w => w.length > 2).length));
    const src = 'Source: C8 org chart slides, October FY27. Names, positions and reporting lines only.';
    if (action === 'vacancies') return { vacancies: all.filter(p => p.kind === 'vacant').map(p => ({ role: p.position, department: p.department, reports_to: label(by.get(p.parent_id) || {}), flag: p.status_flag })), note: src };
    if (action === 'department') { const l = all.filter(p => p.kind !== 'group' && t && (nm(p.department).includes(t) || nm(p.team).includes(t))); return { matches: l.map(p => ({ ...brief(p), reports_to: label(by.get(p.parent_id) || {}) })), note: src }; }
    if (action === 'role') { const l = all.filter(p => t && nm(p.position).includes(t)); return { matches: l.map(p => ({ ...brief(p), reports_to: label(by.get(p.parent_id) || {}) })), note: src }; }
    let hits = nameHits(); if (!hits.length && t) hits = all.filter(p => nm(p.position).includes(t) && p.kind !== 'group');
    if (!hits.length) return { matches: [], note: 'Nobody on the chart matches that. ' + src };
    if (action === 'chain_of_command') { const p = hits[0]; const chain = []; let q = by.get(p.parent_id), n = 0; while (q && n++ < 20) { chain.push({ name: label(q), position: q.position }); q = by.get(q.parent_id); } return { person: brief(p), chain_up_to_top: chain, note: src }; }
    if (action === 'direct_reports') return { people: hits.slice(0, 4).map(p => ({ ...brief(p), direct_reports: (kids.get(p.id) || []).map(d => ({ ...brief(d) })) })), note: src };
    return { matches: hits.slice(0, 6).map(full), note: hits.length > 6 ? 'More than six matches; ask the user to be more specific. ' + src : src };
  },

  async budget({ action = 'overview', section, brand, text }) {
    const v = (await q(`SELECT fy, version, max(id) m FROM budget_lines GROUP BY 1,2 ORDER BY m DESC LIMIT 1`)).rows[0];
    if (!v) return { error: 'No budget has been loaded yet.' };
    const meta = { budget: v.fy, version: v.version, note: 'FY27 budget (July 2026 to June 2027); AUD.' };
    const lines = async (where, args) => (await q(`SELECT section, brand, line, period, value::float8 v, unit FROM budget_lines WHERE fy=$1 AND version=$2 ${where} ORDER BY id`, [v.fy, v.version, ...args])).rows;
    const shape = rows => { const m = new Map(); for (const r of rows) { const k = r.section + '|' + r.brand + '|' + r.line; if (!m.has(k)) m.set(k, { section: r.section, brand: r.brand || undefined, line: r.line, unit: r.unit, values: {} }); m.get(k).values[r.period] = r.unit === 'AUD' ? r0(r.v) : r2(r.v); }
      return [...m.values()].map(x => { const a = x.values.FY26A, b = x.values.FY27B; if (a != null && b != null && a) x.change_pct = pct(b, a); return x; }); };
    if (action === 'overview') {
      const secs = (await q(`SELECT section, count(*) n FROM budget_lines WHERE fy=$1 AND version=$2 GROUP BY 1`, [v.fy, v.version])).rows;
      const head = shape(await lines(`AND ((section='network_sales' AND line IN ('Total network sales')) OR (section='revenue' AND line='Total revenue') OR (section='profit' AND line IN ('Operating profit before investment projects','EBITDA before shareholder costs','Net profit after tax','Dividends')) OR (section='expense' AND line IN ('Employment costs','Total expenses')) OR (section='store_count' AND brand='Total network') OR (section='headcount' AND brand='' AND line LIKE 'Closing headcount (C8)'))`, []));
      return { ...meta, sections: secs.map(s => s.section), headline: head };
    }
    if (action === 'section') { if (!section) return { error: 'section needed' }; const rows = await lines(`AND section=$3 AND ($4::text IS NULL OR brand ILIKE '%'||$4||'%')`, [section, brand || null]); if (!rows.length) return { error: 'No such section (or brand). Sections: network_sales, estate_sales_by_brand, store_count, openings, greenfield, revenue, expense, profit, marketing_pl, cashflow, headcount' }; return { ...meta, lines: shape(rows) }; }
    if (action === 'find') { if (!text) return { error: 'text needed' }; const rows = await lines(`AND (line ILIKE '%'||$3||'%' OR brand ILIKE '%'||$3||'%') AND ($4::text IS NULL OR section=$4)`, [text, section || null]); return { ...meta, lines: shape(rows).slice(0, 40) }; }
    if (action === 'notes') { const r = (await q(`SELECT topic, note FROM budget_notes WHERE fy=$1 AND version=$2 AND ($3::text IS NULL OR topic ILIKE '%'||$3||'%' OR note ILIKE '%'||$3||'%') ORDER BY id`, [v.fy, v.version, text || null])).rows; return { ...meta, notes: r }; }
    if (action === 'vs_actual') {
      const wk = (await q(`SELECT count(DISTINCT week_ending) n, min(week_ending)::text mn, max(week_ending)::text mx FROM weekly_sales WHERE week_ending > '2026-07-05'`)).rows[0];
      const act = (await q(`SELECT s.brand, sum(w.sales)::float8 s FROM weekly_sales w JOIN stores s ON s.id=w.store_id WHERE w.week_ending > '2026-07-05' GROUP BY 1`)).rows;
      const bud = await lines(`AND section='estate_sales_by_brand' AND period='FY27B'`, []); const n = Number(wk.n);
      const alias = { 'Acai Bros': 'Acai Brothers', 'Wok In A Box - OTR': 'Wok in a Box OTR' };
      return { ...meta, weeks_of_actuals_held: n, from_week_ending: wk.mn, to_week_ending: wk.mx,
        by_brand: act.map(a => { const b = bud.find(x => x.brand.toLowerCase() === (alias[a.brand] || a.brand).toLowerCase()); const runrate = b ? b.v / 52 * n : null; return { brand: a.brand, actual_sales: r0(a.s), budget_existing_estate_run_rate: r0(runrate), difference_pct: runrate ? pct(a.s, runrate) : null }; }),
        caution: 'Approximate only: the budget run-rate is the existing-estate annual figure divided by 52 and multiplied by the weeks held (no seasonality, no greenfield timing), while actuals include every store reporting, including new openings. Weekly Sales Report and budget are not the same basis.' };
    }
    return { error: 'unknown action' };
  },


  async pipeline({ action = 'overview', kind, brand, state, status, text, store_id, months = 12, upcoming_only, limit = 25 }) {
    const meta = (await q(`SELECT max(as_of)::text a, count(*) n FROM pipeline_projects`).catch(() => ({ rows: [{ n: 0 }] }))).rows[0];
    if (!Number(meta.n)) return { error: 'The Network Tracker pipeline has not been loaded yet.' };
    const lim = Math.max(1, Math.min(60, Number(limit) || 25));
    const KINDS = { greenfield: 'greenfield', new: 'greenfield', cous: 'cous', landbank: 'cous', opened: 'opened', transfer: 'transfer', transfers: 'transfer', closure: 'closure', closures: 'closure', fa_renewal: 'fa_renewal', fa: 'fa_renewal', lease_renewal: 'lease_renewal', lease: 'lease_renewal' };
    const kd = kind ? KINDS[String(kind).toLowerCase().replace(/[^a-z_]/g, '')] : null;
    const note = `The latest dated entry in the tracker is ${meta.a}. It is refreshed about every two weeks, so more recent changes may not show. Entries after that date are plans, not facts.`;
    const DONE = /^(completed|approved|received|yes|returned|paid|issued|signed|\d{4}-\d{2}-\d{2})/i;
    const progress = steps => { const live = steps.filter(s => !/^(n\/a|no|tbc|-)$/i.test(s.value) && !/^\$?[\d,.]+$/.test(s.value)); const done = live.filter(s => DONE.test(s.value)); const open = live.filter(s => !DONE.test(s.value));
      return { steps_done: done.length, steps_counted: live.length, next_open: open.slice(0, 3).map(s => `${s.step}: ${s.value}`), delayed_steps: live.filter(s => /^delayed/i.test(s.value)).map(s => `${s.step}: ${s.value}`) }; };
    const attach = async rows => { if (!rows.length) return rows; const st = (await q(`SELECT project_id, phase, step, value FROM pipeline_steps WHERE project_id = ANY($1) ORDER BY project_id, seq`, [rows.map(r => r.id)])).rows;
      const by = {}; for (const s of st) (by[s.project_id] = by[s.project_id] || []).push(s); return rows.map(r => ({ ...r, progress: progress(by[r.id] || []), _steps: by[r.id] || [] })); };
    const cols = `id, kind, restaurant, brand, state, gsm, partner, status, at_risk, target_date::text, actual_date::text, delayed_days, delay_reason, budgeted_date::text, est_weekly_sales::float8, lost_revenue::float8, fa_expiry::text, lease_expiry::text, store_id, (COALESCE(actual_date, target_date) - CURRENT_DATE) AS days_until`;
    const filt = (args) => { const w = []; if (kd) { args.push(kd); w.push(`kind=$${args.length}`); } if (brand) { args.push('%' + brand + '%'); w.push(`brand ILIKE $${args.length}`); } if (state) { args.push(String(state).toUpperCase()); w.push(`upper(state)=$${args.length}`); } if (status) { args.push('%' + status + '%'); w.push(`status ILIKE $${args.length}`); } if (store_id) { args.push(store_id); w.push(`store_id=$${args.length}`); } if (text) { args.push('%' + text + '%'); w.push(`restaurant ILIKE $${args.length}`); } return w.length ? 'WHERE ' + w.join(' AND ') : ''; };
    const lite = r => { const { _steps, id, ...x } = r; return x; };
    if (action === 'overview') {
      const k = (await q(`SELECT kind, count(*) n FROM pipeline_projects GROUP BY 1 ORDER BY 2 DESC`)).rows;
      const g = (await q(`SELECT brand, state, status, count(*) n FROM pipeline_projects WHERE kind IN ('greenfield','cous') GROUP BY 1,2,3 ORDER BY 1,2`)).rows;
      const act = (await q(`SELECT type, count(*) n FROM pipeline_activity GROUP BY 1 ORDER BY 2 DESC`)).rows;
      return { latest_entry: meta.a, sites_by_tab: k, new_store_pipeline: g, activity_by_type: act, note };
    }
    if (action === 'list') {
      const args = []; let w = filt(args); if (upcoming_only) w += (w ? ' AND ' : 'WHERE ') + `COALESCE(actual_date, target_date) >= CURRENT_DATE - 7`;
      const r = await attach((await q(`SELECT ${cols} FROM pipeline_projects ${w} ORDER BY COALESCE(actual_date, target_date, fa_expiry, lease_expiry) NULLS LAST, restaurant LIMIT ${lim}`, args)).rows);
      return { latest_entry: meta.a, count: r.length, sites: r.map(lite), note };
    }
    if (action === 'site') {
      if (!store_id && !text) return { error: 'give a store_id or the site name in text' };
      const args = []; const w = filt(args);
      const r = await attach((await q(`SELECT ${cols} FROM pipeline_projects ${w} ORDER BY kind, COALESCE(actual_date, target_date) NULLS LAST LIMIT 12`, args)).rows);
      const act = (await q(`SELECT type, action_date::text d, franchise_partner, incentive, description FROM pipeline_activity WHERE ${store_id ? 'store_id=$1' : 'restaurant ILIKE $1'} ORDER BY action_date NULLS LAST LIMIT 12`, [store_id || '%' + text + '%'])).rows;
      const ls = (await q(`SELECT site, term_years::float8 term_years, commencement::text, expiry::text, bank_guarantee::float8, landlord, tenant, further_term FROM lease_liability WHERE ${store_id ? 'store_id=$1' : 'site ILIKE $1'}`, [store_id || '%' + text + '%'])).rows;
      return { latest_entry: meta.a, tracker_entries: r.map(x => ({ ...lite(x), steps: x._steps.map(s => `${s.step}: ${s.value}`) })), activity: act, c8_lease: ls, note };
    }
    if (action === 'delayed') {
      const args = []; let w = filt(args); w += (w ? ' AND ' : 'WHERE ') + `kind IN ('greenfield','cous','opened') AND delayed_days > 0`;
      const r = await attach((await q(`SELECT ${cols} FROM pipeline_projects ${w} ORDER BY delayed_days DESC LIMIT ${lim}`, args)).rows);
      return { latest_entry: meta.a, count: r.length, sites: r.map(lite), note };
    }
    if (action === 'expiries') {
      const m = Math.max(1, Math.min(60, Number(months) || 12)); const args = [m]; let extra = '';
      if (brand) { args.push('%' + brand + '%'); extra += ` AND brand ILIKE $${args.length}`; } if (state) { args.push(String(state).toUpperCase()); extra += ` AND upper(state)=$${args.length}`; }
      const fa = (await q(`SELECT DISTINCT ON (restaurant, brand) restaurant, brand, state, gsm, at_risk, fa_expiry::text, lease_expiry::text, (fa_expiry - CURRENT_DATE) days_to_fa_expiry, (lease_expiry - CURRENT_DATE) days_to_lease_expiry, store_id, kind
        FROM pipeline_projects WHERE kind IN ('fa_renewal','lease_renewal') AND ((fa_expiry <= CURRENT_DATE + ($1 || ' months')::interval) OR (lease_expiry <= CURRENT_DATE + ($1 || ' months')::interval)) ${extra}
        ORDER BY restaurant, brand, kind LIMIT 80`, args)).rows;
      const ll = (await q(`SELECT site, expiry::text, (expiry - CURRENT_DATE) days_to_expiry, landlord, bank_guarantee::float8, further_term, store_id FROM lease_liability WHERE expiry <= CURRENT_DATE + ($1 || ' months')::interval ORDER BY expiry LIMIT 40`, [m])).rows;
      const up = r => (r.days_to_fa_expiry ?? 1) >= 0 && (r.days_to_lease_expiry ?? 1) >= 0; const upl = ll.filter(x => x.days_to_expiry >= 0);
      return { latest_entry: meta.a, window_months: m, coming_up: fa.filter(up).slice(0, 40), c8_held_leases_coming_up: upl, already_past_dates: { renewals_tracker: fa.filter(r => !up(r)).slice(0, 15), c8_held_leases: ll.filter(x => x.days_to_expiry < 0), caution: 'These dates are already behind us; the tracker may simply not have been updated, or the renewal may be done. Do not call them expired without saying so.' }, note };
    }
    if (action === 'activity') {
      const w = []; const args = []; if (kind) { args.push('%' + kind + '%'); w.push(`type ILIKE $${args.length}`); } if (brand) { args.push('%' + brand + '%'); w.push(`brand ILIKE $${args.length}`); } if (state) { args.push(String(state).toUpperCase()); w.push(`upper(state)=$${args.length}`); } if (text) { args.push('%' + text + '%'); w.push(`restaurant ILIKE $${args.length}`); }
      const r = (await q(`SELECT brand, restaurant, state, type, action_date::text d, franchise_partner, incentive, description FROM pipeline_activity ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY action_date NULLS LAST LIMIT ${lim}`, args)).rows;
      const c = (await q(`SELECT type, count(*) n FROM pipeline_activity GROUP BY 1 ORDER BY 2 DESC`)).rows;
      return { latest_entry: meta.a, totals_by_type: c, rows: r, note };
    }
    if (action === 'step') {
      if (!text) return { error: 'give the step name in text, e.g. "Lease Signed"' };
      const args = ['%' + text + '%']; let w = 'WHERE s.step ILIKE $1';
      if (kd) { args.push(kd); w += ` AND p.kind=$${args.length}`; } if (brand) { args.push('%' + brand + '%'); w += ` AND p.brand ILIKE $${args.length}`; } if (state) { args.push(String(state).toUpperCase()); w += ` AND upper(p.state)=$${args.length}`; }
      const rows = (await q(`SELECT p.kind, p.restaurant, p.brand, p.state, s.step, s.value FROM pipeline_steps s JOIN pipeline_projects p ON p.id=s.project_id ${w} ORDER BY p.kind, p.restaurant LIMIT 400`, args)).rows;
      if (!rows.length) return { latest_entry: meta.a, matched_steps: [], note: 'No checklist step has a name like that. Steps include: FP Application, Location Approved, Lease Signed, LOT Issued, Prepare Fran. Docs, Fran Docs Issued, Out of Disclosure, Fran Docs Signed, Fee Collected, Design Approval, Signage Approval, Tender Shopfit, Permit Application, Fitout Status, FP Induction, Training Planner, Opening Checklist, Grand Opening Date.' };
      const isDate = v => /^\d{4}-\d{2}-\d{2}$/.test(v); const groups = {};
      for (const r of rows) { const g = `${r.kind} / ${r.step}`; const o = (groups[g] = groups[g] || { sites: 0, by_value: {}, dated: 0 }); o.sites++; const k = isDate(r.value) ? 'a date' : r.value; o.by_value[k] = (o.by_value[k] || 0) + 1; if (isDate(r.value)) o.dated++; }
      return { latest_entry: meta.a, by_tab_and_step: groups, sites: rows.slice(0, lim).map(r => ({ tab: r.kind, restaurant: r.restaurant, brand: r.brand, state: r.state, step: r.step, value: r.value })), note: note + ' Values are status words or dates exactly as the tracker holds them.' };
    }
    return { error: 'unknown action' };
  },
  async finance({ action = 'overview', month, text, statement = 'pl' }, ctx) {
    const ar = (ctx && ctx.areas) || ALL_AREAS; const hide = ar.includes('exec_pay') ? (x => x) : (rows => rows.filter(r => !EXEC_PAY.test(r.line || '')));
    const months = (await q(`SELECT to_char(period,'YYYY-MM') m FROM fin_reports ORDER BY period DESC`).catch(() => ({ rows: [] }))).rows.map(r => r.m);
    if (!months.length) return { error: 'No finance reports have been loaded yet.' };
    const m = month && /^\d{4}-\d{2}$/.test(month) ? month : months[0];
    const held = { months_held: months, note: 'Monthly Finance Board Report; AUD. Months not listed are not loaded.' };
    const one = async (sql, args) => (await q(sql, args)).rows;
    const v = (rows, line, f) => { const r = rows.find(x => x.line === line); return r ? r[f] : null; };
    if (action === 'overview') {
      const rows = await one(`SELECT to_char(r.period,'YYYY-MM') AS month,
        (SELECT actual::float8 FROM fin_pl WHERE period=r.period AND kind='month' AND line='Total Revenue' LIMIT 1) revenue,
        (SELECT actual::float8 FROM fin_pl WHERE period=r.period AND kind='month' AND line='Operating Profit Before Depn & Amort.' LIMIT 1) operating_profit,
        (SELECT actual::float8 FROM fin_pl WHERE period=r.period AND kind='month' AND line='Net Income' LIMIT 1) net_income,
        (SELECT amount::float8 FROM fin_bs WHERE period=r.period AND line='Total Cash & Equivalents' LIMIT 1) cash,
        (SELECT amount::float8 FROM fin_bs WHERE period=r.period AND line='CBA Loan Facility' LIMIT 1) cba_loan
        FROM fin_reports r ORDER BY r.period DESC`);
      return { ...held, by_month: rows.map(r => ({ ...r, net_bank_debt: r.cba_loan != null && r.cash != null ? Math.round(r.cba_loan - r.cash) : null })) };
    }
    if (!months.includes(m)) return { error: `No finance report is held for ${m}.`, ...held };
    if (action === 'cash_flow') return { ...held, ...(await FIN.cashFlow(q, m)) };
    if (action === 'month') {
      const sum = await one(`SELECT line, actual::float8 actual, budget::float8 budget FROM fin_pl WHERE to_char(period,'YYYY-MM')=$1 AND kind='summary' ORDER BY seq`, [m]);
      const mo = await one(`SELECT line, actual::float8 actual, budget::float8 budget, ly::float8 last_year FROM fin_pl WHERE to_char(period,'YYYY-MM')=$1 AND kind='month' AND line IN ('Total Revenue','Total Expenses','Operating Profit Before Depn & Amort.','EBITDA','Net Income','Dividend','Retained Income')`, [m]);
      const yt = await one(`SELECT line, actual::float8 actual, budget::float8 budget, ly::float8 last_year FROM fin_pl WHERE to_char(period,'YYYY-MM')=$1 AND kind='ytd' AND line IN ('Total Revenue','Total Expenses','Operating Profit Before Depn & Amort.','EBITDA','Net Income','Dividend','Retained Income')`, [m]);
      const bs = await one(`SELECT line, amount::float8 amount, prior::float8 prior FROM fin_bs WHERE to_char(period,'YYYY-MM')=$1 AND line IN ('Total Cash & Equivalents','CBA Loan Facility','Total Shareholders Loan','Total Assets','Total Liabilities','Total Equity','Total Liabilities & Equity')`, [m]);
      const cash = v(bs, 'Total Cash & Equivalents', 'amount'), cba = v(bs, 'CBA Loan Facility', 'amount');
      return { ...held, month: m, summary_pl_vs_budget: sum.length ? hide(sum) : undefined, month_pl: hide(mo), year_to_date_pl: hide(yt), balance_sheet: bs, net_bank_debt: cba != null && cash != null ? Math.round(cba - cash) : null, note: 'Use cash_flow for the derived cash flow, lines to search individual lines, commentary for the finance team\'s explanations.' };
    }
    if (action === 'lines') {
      const pat = '%' + String(text || '').replace(/[%_]/g, '') + '%';
      if (statement === 'bs') return { ...held, month: m, statement: 'balance sheet', lines: await one(`SELECT grp, section, line, amount::float8 amount, prior::float8 prior_month, ly::float8 same_month_last_year FROM fin_bs WHERE to_char(period,'YYYY-MM')=$1 AND line ILIKE $2 ORDER BY seq LIMIT 40`, [m, pat]) };
      const mo = await one(`SELECT section, line, actual::float8 month_actual, budget::float8 month_budget, ly::float8 same_month_last_year FROM fin_pl WHERE to_char(period,'YYYY-MM')=$1 AND kind='month' AND line ILIKE $2 ORDER BY seq LIMIT 40`, [m, pat]);
      const yt = await one(`SELECT line, actual::float8 ytd_actual, budget::float8 ytd_budget, ly::float8 ytd_last_year FROM fin_pl WHERE to_char(period,'YYYY-MM')=$1 AND kind='ytd' AND line ILIKE $2 ORDER BY seq LIMIT 40`, [m, pat]);
      const lines = hide(mo).map(r => ({ ...r, ...(yt.find(y => y.line === r.line) || {}) })); return { ...held, month: m, statement: 'profit and loss', lines, ...(!lines.length && !ar.includes('exec_pay') && EXEC_PAY.test(String(text || '')) ? { note: 'Executive and director pay lines are outside your access.' } : {}) };
    }
    if (action === 'trend') {
      const name = String(text || '').trim(); if (!name) return { error: 'Give the line name in text, e.g. "CBA Loan Facility" or "Royalties".' };
      const pat = '%' + name.replace(/[%_]/g, '') + '%';
      const bs = hide(await one(`SELECT to_char(period,'YYYY-MM') AS month, line, amount::float8 value FROM fin_bs WHERE line ILIKE $1 ORDER BY period, seq`, [pat]));
      const pl = hide(await one(`SELECT to_char(period,'YYYY-MM') AS month, line, actual::float8 value FROM fin_pl WHERE kind='month' AND line ILIKE $1 ORDER BY period, seq`, [pat]));
      const group = (rows, kind) => { const by = {}; for (const r of rows) (by[r.line] = by[r.line] || []).push({ month: r.month, value: r.value }); return Object.entries(by).slice(0, 4).map(([line, series]) => ({ statement: kind, line, series })); };
      return { ...held, matches: [...group(bs, 'balance sheet (month-end balance)'), ...group(pl, 'profit and loss (month actual)')], note: 'Months held only; gaps are months not loaded.' };
    }
    if (action === 'commentary') {
      if (!ar.includes('finance_commentary')) return { error: 'The finance team commentary is outside your access.' };
      const r = (await one(`SELECT commentary FROM fin_reports WHERE to_char(period,'YYYY-MM')=$1`, [m]))[0]; const t = r?.commentary || '';
      if (!t) return { ...held, month: m, commentary: 'This report has no written commentary.' };
      const paras = t.split(/\n/).filter(Boolean); const words = String(text || '').toLowerCase().split(/\s+/).filter(w => w.length > 2);
      const keep = words.length ? paras.filter(x => words.some(w => x.toLowerCase().includes(w))) : paras;
      return { ...held, month: m, commentary: (keep.length ? keep : paras).join('\n').slice(0, 4000) };
    }
    return { error: 'unknown action' };
  },
  async data_status(_in, ctx) {
    const ar = (ctx && ctx.areas) || ALL_AREAS;
    const lw = await latestWeek();
    const wk = (await q(`SELECT count(DISTINCT week_ending) n, min(week_ending)::text mn FROM weekly_sales`)).rows[0];
    const br = (await q(`SELECT brand, count(*) n FROM stores GROUP BY 1 ORDER BY 2 DESC`)).rows;
    const ll = (await q(`SELECT loaded_at::text, kind, file_name FROM load_log ORDER BY id DESC LIMIT 1`)).rows[0];
    const bud = (await q(`SELECT fy, version, count(*) n FROM budget_lines GROUP BY 1,2`).catch(() => ({ rows: [] }))).rows;
    const dly = (await q(`SELECT max(sales_date)::text mx, min(sales_date)::text mn, count(DISTINCT sales_date) n, count(DISTINCT store_id) st FROM daily_sales`).catch(() => ({ rows: [{}] }))).rows[0];
    const items = (await q(`SELECT brand, period_start::text ps, period_end::text pe, count(DISTINCT store_name) stores, count(DISTINCT item_name) items FROM item_sales GROUP BY 1,2,3 ORDER BY pe DESC`).catch(() => ({ rows: [] }))).rows;
    const org = (await q(`SELECT count(*) FILTER (WHERE kind='person') people, count(*) FILTER (WHERE kind='vacant') vacancies FROM people`).catch(() => ({ rows: [{}] }))).rows[0];
    const pl = (await q(`SELECT max(as_of)::text a, count(*) n FROM pipeline_projects`).catch(() => ({ rows: [{ n: 0 }] }))).rows[0];
    const fin = (await q(`SELECT to_char(period,'YYYY-MM') m FROM fin_reports ORDER BY period DESC`).catch(() => ({ rows: [] }))).rows.map(r => r.m);
    const bd = (await q(`SELECT count(*) n, min(to_char(period,'YYYY-MM')) a, max(to_char(period,'YYYY-MM')) b, count(*) FILTER (WHERE summary IS NOT NULL) s FROM board_docs`).catch(() => ({ rows: [{ n: 0 }] }))).rows[0];
    const full = { board_papers: Number(bd.n) ? { papers: Number(bd.n), summarised: Number(bd.s), earliest_month: bd.a, latest_month: bd.b } : 'not loaded', finance_reports: fin.length ? { months_held: fin, note: 'Monthly Finance Board Reports; cash flow is derived, not reported.' } : 'not loaded', network_tracker_pipeline: Number(pl.n) ? { latest_entry: pl.a, sites: Number(pl.n) } : 'not loaded', budget: bud.length ? bud : 'not loaded', item_sales: items.length ? items : 'not loaded', organisation_chart: org.people ? { people: Number(org.people), vacancies: Number(org.vacancies), source: 'October FY27 org chart slides' } : 'not loaded', latest_week_ending: lw, weeks_held: Number(wk.n), earliest_week_ending: wk.mn, stores_by_brand: br,
      last_load: ll, limitations: [
        `Store sales history: ${wk.n} weeks, from ${wk.mn} (the weekly detailed sales records). More builds up as weeks are added.`,
        'In the weekly figures, orders and ATV are held for the latest week only (daily sales hold orders every day).',
        'Weeks end on a Sunday.',
        Number(dly.n) ? `Daily sales: ${dly.n} days held, ${dly.mn} to ${dly.mx}, ${dly.st} stores (orders per day included). The daily figures come from a different Power BI dataset and can differ from the weekly report by a few percent.` : 'Daily sales are not loaded yet.',
        'Opening dates: 51 stores have a reliable date; many older stores only have a franchise-agreement start date (marked low reliability); some have none.',
        'Address, trading company and BDM exist only for stores found in the SharePoint franchisee list (Huxtaburger, Acai Bros and most newer stores are not in it).',
      ] };
    // describe only what this person may use
    const mn = (await q("SELECT count(*) n FROM manual_docs WHERE kind='manual'").catch(() => ({ rows: [{ n: 0 }] }))).rows[0]; full.manuals = Number(mn.n) ? { manuals_held: Number(mn.n) } : 'not loaded';
    if (!ar.includes('manuals')) delete full.manuals;
    const lg = (await q("SELECT count(*) n FROM manual_docs WHERE kind='legal'").catch(() => ({ rows: [{ n: 0 }] }))).rows[0]; if (ar.includes('legal')) full.legal_documents = Number(lg.n) ? { documents_held: Number(lg.n) } : 'not loaded';
    if (!ar.includes('board_papers')) delete full.board_papers;
    if (!ar.includes('finance')) delete full.finance_reports;
    if (!ar.includes('budget')) delete full.budget;
    if (!ar.includes('org')) delete full.organisation_chart;
    if (!ar.includes('sales')) { for (const k of ['network_tracker_pipeline', 'item_sales', 'latest_week_ending', 'weeks_held', 'earliest_week_ending', 'stores_by_brand', 'last_load']) delete full[k]; full.limitations = []; }
    return full;
  },
};

impl.board_papers = BOARD.tool;
impl.manuals = a => MANUALS.tool(a, 'manual');
impl.legal_documents = a => MANUALS.tool(a, 'legal');
impl.store_agreements = async ({ action = 'store', store_id, kind = 'fa', within_months = 12, brand, state, limit = 50 }) => {
  const cols = `s.id, s.name, s.brand, s.state, s.trading_company, s.abn, s.royalty_rate, s.fa_start::text fa_start, s.fa_end::text fa_end, s.fa_options, s.lease_start::text lease_start, s.lease_end::text lease_end, s.lease_options, s.landlord, s.site_size, s.annual_rent, (s.fa_end - current_date) fa_days, (s.lease_end - current_date) lease_days`;
  const shape = x => ({ store_id: x.id, store: x.name, brand: x.brand, state: x.state, trading_company: x.trading_company, abn: x.abn, royalty_rate_pct: x.royalty_rate == null ? null : Math.round(Number(x.royalty_rate) * 10000) / 100,
    franchise_agreement: { start: x.fa_start, end: x.fa_end, options: x.fa_options, days_to_end: x.fa_days }, lease: { start: x.lease_start, end: x.lease_end, options: x.lease_options, days_to_end: x.lease_days, landlord: x.landlord, site_size: x.site_size, annual_rent: x.annual_rent } });
  if (action === 'store') {
    const r = (await q(`SELECT ${cols} FROM stores s WHERE s.id=$1`, [Number(store_id) || 0])).rows[0]; if (!r) return { error: 'unknown store_id' };
    const has = r.royalty_rate != null || r.fa_end || r.lease_end || r.abn; return has ? shape(r) : { store: r.name, brand: r.brand, note: 'No franchise agreement or lease details are held for this store (it is not in the Franchise Master file).' };
  }
  if (action === 'expiring') {
    const col = kind === 'lease' ? 's.lease_end' : 's.fa_end'; const m = Math.max(1, Math.min(120, Number(within_months) || 12)); const n = Math.max(1, Math.min(100, Number(limit) || 50));
    const r = (await q(`SELECT ${cols} FROM stores s WHERE s.active AND ${col} IS NOT NULL AND ${col} <= current_date + ($1 || ' months')::interval AND ($2::text IS NULL OR s.brand ILIKE '%'||$2||'%') AND ($3::text IS NULL OR s.state=upper($3)) ORDER BY ${col}, s.name LIMIT $4`, [String(m), brand || null, state || null, n])).rows;
    const held = Number((await q(`SELECT count(*) n FROM stores s WHERE s.active AND ${col} IS NOT NULL`)).rows[0].n);
    return { kind: kind === 'lease' ? 'lease' : 'franchise agreement', within_months: m, stores_with_this_date_on_record: held, count: r.length, stores: r.map(shape), note: 'Includes agreements already past their end date (days_to_end is negative). Stores not in the Franchise Master have no dates.' };
  }
  return { error: 'unknown action' };
};
async function run(name, input, ctx) {   // ctx = { areas: [...] }; without it (scripts, tests) everything is allowed
  if (!impl[name]) return { error: 'unknown tool ' + name };
  if (ctx && ctx.areas && name !== 'data_status' && !ctx.areas.includes(AREA_OF[name])) return { error: 'That is outside this person\'s access, so it cannot be looked up.' };
  try { return await impl[name](input || {}, ctx); } catch (e) { return { error: 'query failed: ' + e.message }; }
}
module.exports = { defs, defsFor, run, latestWeek, ALL_AREAS, AREA_OF };
